// js/tarefas.js
document.getElementById('cadastroTarefaForm').addEventListener('submit', function (event) {
    event.preventDefault();
  
    const data = {
      nome_tarefa: document.getElementById('nome_tarefa').value,
      descricao_tarefa: document.getElementById('descricao_tarefa').value,
      nome_setor: document.getElementById('nome_setor').value,
      prioridade: document.getElementById('prioridade').value,
      status: document.getElementById('status').value,
      usuario_id: document.getElementById('usuario_id').value
    };
  
    fetch('/api/tarefas/cadastrar', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(data)
    })
      .then(response => response.json())
      .then(data => {
        alert(data.message);
      })
      .catch(error => {
        console.error('Erro:', error);
      });
  });
  