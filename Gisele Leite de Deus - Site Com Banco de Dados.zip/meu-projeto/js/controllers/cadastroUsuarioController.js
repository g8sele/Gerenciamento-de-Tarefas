const db = require('../index').db; // Acessa a conexão com o banco de dados

// Função para cadastrar usuário
exports.cadastrarUsuario = (req, res) => {
  const { nome, email } = req.body;

  if (!nome || !email) {
    return res.status(400).json({ success: false, message: "Nome e email são obrigatórios" });
  }

  // Insira os dados no banco de dados
  const query = 'INSERT INTO usuario (nome, email) VALUES (?, ?)';
  db.query(query, [nome, email], (err, result) => {
    if (err) {
      console.error(err);
      return res.status(500).json({ success: false, message: "Erro ao cadastrar usuário" });
    }

    res.status(201).json({ success: true, message: "Usuário cadastrado com sucesso" });
  });
};
