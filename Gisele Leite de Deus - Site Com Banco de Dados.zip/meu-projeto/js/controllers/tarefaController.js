// controllers/tarefaController.js
const listarTarefas = (req, res) => {
  const db = req.app.locals.db;
  const query = 'SELECT * FROM tarefa';

  db.query(query, (err, results) => {
    if (err) {
      console.error('Erro ao listar tarefas:', err);
      return res.status(500).json({ message: 'Erro ao listar tarefas' });
    }
    res.json(results);
  });
};

const editarTarefa = (req, res) => {
  const { id } = req.params;
  const { nome_tarefa, descricao_tarefa, nome_setor, prioridade, status } = req.body;
  const db = req.app.locals.db;
  const query = 'UPDATE tarefa SET nome_tarefa = ?, descricao_tarefa = ?, nome_setor = ?, prioridade = ?, status = ? WHERE id_tarefa = ?';

  db.query(query, [nome_tarefa, descricao_tarefa, nome_setor, prioridade, status, id], (err) => {
    if (err) {
      console.error('Erro ao editar tarefa:', err);
      return res.status(500).json({ message: 'Erro ao editar tarefa' });
    }
    res.json({ message: 'Tarefa atualizada com sucesso' });
  });
};

const deletarTarefa = (req, res) => {
  const { id } = req.params;
  const db = req.app.locals.db;
  const query = 'DELETE FROM tarefa WHERE id_tarefa = ?';

  db.query(query, [id], (err) => {
    if (err) {
      console.error('Erro ao deletar tarefa:', err);
      return res.status(500).json({ message: 'Erro ao excluir tarefa' });
    }
    res.json({ message: 'Tarefa excluída com sucesso' });
  });
};

module.exports = {
  listarTarefas,
  editarTarefa,
  deletarTarefa
};
