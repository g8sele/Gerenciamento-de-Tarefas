// js/cadastroUsuario.js
document.addEventListener('DOMContentLoaded', function() {
    const form = document.querySelector('form');
    const nomeInput = document.getElementById('nome');
    const emailInput = document.getElementById('email');
    
    form.addEventListener('submit', function(event) {
        event.preventDefault();  // Previne o envio do formulário até que a validação seja feita
        
        // Validação dos campos
        if (!nomeInput.value.trim() || !emailInput.value.trim()) {
            alert("Por favor, preencha todos os campos.");
            return;
        }

        // Validação do e-mail
        const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
        if (!emailRegex.test(emailInput.value)) {
            alert("Por favor, insira um e-mail válido.");
            return;
        }

        // Supondo que o envio para o banco de dados seja feito com fetch para uma API
        const userData = {
            nome: nomeInput.value,
            email: emailInput.value
        };

        // Enviar os dados para o servidor
        fetch('http://localhost:3000/api/usuarios', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(userData)
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('Cadastro concluído com sucesso');
                form.reset();  // Limpar os campos após o envio
            } else {
                alert('Erro ao cadastrar usuário. Tente novamente.');
            }
        })
        .catch(error => {
            console.error('Erro ao registrar usuário:', error);
            alert('Ocorreu um erro. Tente novamente.');
        });
    });
});
