const express = require('express');
const session = require('express-session');
const bodyParser = require('body-parser');
const app = express();

// Configuração do middleware para analisar os dados do corpo da requisição
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Configuração do express-session
app.use(session({
    secret: 'seu_segredo_aqui', // Utilize um segredo forte
    resave: false,
    saveUninitialized: true,
    cookie: { secure: false } // Para desenvolvimento, setar como false (em produção use true com HTTPS)
}));

// Exemplo de usuários armazenados na sessão
let usuarios = [
    { id: 1, nome: 'Usuário 1' },
    { id: 2, nome: 'Usuário 2' },
    { id: 3, nome: 'Usuário 3' }
];

// Rota para retornar os usuários cadastrados
app.get('/usuarios', (req, res) => {
    res.json(usuarios); // Retorna a lista de usuários
});

// Rota para cadastrar um novo usuário
app.post('/cadastrar', (req, res) => {
    const { nome, email } = req.body;

    // Cadastrar o novo usuário (aqui adicionando na lista 'usuarios' para a sessão)
    const novoUsuario = { id: usuarios.length + 1, nome, email };
    usuarios.push(novoUsuario);

    res.send('Usuário cadastrado com sucesso!');
});

// Inicializando o servidor
const PORT = 3000;
app.listen(PORT, () => {
    console.log(`Servidor rodando em http://localhost:${PORT}`);
});
