// index.js
const express = require('express');
const mysql = require('mysql2');
const bodyParser = require('body-parser');
const cadastroUsuarioRoutes = require('./routes/cadastroUsuario');
const tarefaRoutes = require('./routes/tarefaRoutes');

const app = express();
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Conexão com o banco de dados
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root', // Seu usuário do MySQL
  password: '', // Sua senha do MySQL
  database: 'gerenciamentotarefa'
});

db.connect((err) => {
  if (err) {
    console.error('Erro ao conectar ao banco de dados:', err);
    return;
  }
  console.log('Conectado ao banco de dados MySQL');
});

// Tornando a conexão acessível em outras partes do app
app.locals.db = db;

// Rotas
app.use('/api/usuarios', cadastroUsuarioRoutes); // Rota de usuário
app.use('/api/tarefas', tarefaRoutes); // Rota de tarefa

// Servir arquivos estáticos (HTML, CSS, etc.)
app.use(express.static(__dirname));

// Inicialização do servidor
const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Servidor rodando em http://localhost:${PORT}`);
});
