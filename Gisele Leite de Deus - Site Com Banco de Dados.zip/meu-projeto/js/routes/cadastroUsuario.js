const express = require('express');
const router = express.Router();
const cadastroUsuarioController = require('../controllers/cadastroUsuarioController');

// Rota para cadastrar um novo usuário
router.post('/', cadastroUsuarioController.cadastrarUsuario);

module.exports = router;
