// routes/tarefaRoutes.js
const express = require('express');
const router = express.Router();
const tarefaController = require('../controllers/tarefaController');

// Rotas para gerenciamento de tarefas
router.get('/', tarefaController.listarTarefas);        // Listar todas as tarefas
router.post('/cadastrar', tarefaController.cadastrarTarefa); // Cadastrar uma nova tarefa
router.put('/editar/:id', tarefaController.editarTarefa);    // Editar uma tarefa existente
router.delete('/:id', tarefaController.deletarTarefa);       // Excluir uma tarefa

module.exports = router;
