// js/gerenciarTarefas.js
document.addEventListener('DOMContentLoaded', function () {
    // Carregar as tarefas quando a página for carregada
    fetch('/api/tarefas')
        .then(response => response.json())
        .then(data => {
            data.forEach(task => {
                renderTask(task);
            });
        })
        .catch(error => {
            console.error('Erro ao carregar tarefas:', error);
        });
});

function renderTask(task) {
    const taskItem = document.createElement('div');
    taskItem.className = 'task-item';
    taskItem.innerHTML = `
        <h3>${task.nome_tarefa}</h3>
        <p>Descrição: ${task.descricao_tarefa}</p>
        <p>Setor: ${task.nome_setor}</p>
        <p>Prioridade: ${task.prioridade}</p>
        <p>Status: ${task.status}</p>
        <div class="actions">
            <button class="edit" onclick="editTask(${task.id_tarefa})">Editar</button>
            <button class="delete" onclick="deleteTask(${task.id_tarefa})">Excluir</button>
        </div>
    `;

    // Adicionar a tarefa na coluna correspondente ao status
    const statusColumn = document.getElementById(`task-list-${task.status.toLowerCase().replace(' ', '-')}`);
    statusColumn.appendChild(taskItem);
}

function editTask(taskId) {
    // Redirecionar para a página de cadastro para edição
    window.location.href = `cadTarefas.html?id=${taskId}`;
}

function deleteTask(taskId) {
    if (confirm('Tem certeza que deseja excluir esta tarefa?')) {
        fetch(`/api/tarefas/${taskId}`, {
            method: 'DELETE'
        })
            .then(response => response.json())
            .then(data => {
                alert(data.message);
                window.location.reload();
            })
            .catch(error => {
                console.error('Erro ao excluir tarefa:', error);
            });
    }
}
